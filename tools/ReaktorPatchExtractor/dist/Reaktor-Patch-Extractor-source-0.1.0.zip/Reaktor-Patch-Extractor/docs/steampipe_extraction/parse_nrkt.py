#!/usr/bin/env python3
"""Inspect the object hierarchy stored in Native Instruments NRKT files.

This is a conservative parser for the portions of the Reaktor 4/5/6 binary
serialization that have been verified against SteamPipe.  It does not modify
the source file.  Unknown fields are deliberately left uninterpreted.
"""

from __future__ import annotations

import argparse
import bisect
import json
import struct
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterator


MODULE_MARKER = b"[\x07\x00\x00\x00KSModul"
PORT_CLASSES = (b"KInPort", b"KOutPort")
MODULE_SIGNATURE = 0x0022F300
ROOT_SENTINEL_ID = 0x75646F4D  # bytes spell "Modu"; root has a different schema
MAX_STRING_SIZE = 1 << 20


def u32(data: bytes, offset: int) -> int:
    if offset < 0 or offset + 4 > len(data):
        raise ValueError(f"u32 outside file at 0x{offset:x}")
    return struct.unpack_from("<I", data, offset)[0]


def marker_offsets(data: bytes, marker: bytes) -> Iterator[int]:
    offset = 0
    while True:
        offset = data.find(marker, offset)
        if offset < 0:
            return
        yield offset
        offset += 1


def decode_nrkt_string(data: bytes, length_offset: int) -> tuple[str, int]:
    length = u32(data, length_offset)
    if length > MAX_STRING_SIZE:
        raise ValueError(f"implausible string length {length} at 0x{length_offset:x}")
    start = length_offset + 4
    end = start + length
    if end > len(data):
        raise ValueError(f"string outside file at 0x{length_offset:x}")
    return data[start:end].decode("utf-8", errors="replace"), end


@dataclass
class Module:
    offset: int
    version: int
    signature: int
    kind: int
    object_id: int
    name: str | None = None
    description: str | None = None
    child_count: int = 0
    input_count: int | None = None
    output_count: int | None = None
    x: int | None = None
    y: int | None = None
    width: int | None = None
    height: int | None = None
    children: list["Module"] = field(default_factory=list)

    @property
    def is_macro(self) -> bool:
        return self.kind == 4

    def label(self) -> str:
        if self.name:
            return self.name
        return f"kind-{self.kind}"

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["offset"] = f"0x{self.offset:x}"
        result["signature"] = f"0x{self.signature:08x}"
        return result


@dataclass
class Connection:
    target_local_index: int
    target_input_index: int
    target_object_id: int | None = None
    target_name: str | None = None
    target_kind: int | None = None
    target_input_name: str | None = None


@dataclass
class PortRecord:
    offset: int
    class_name: str
    source_object_id: int | None = None
    source_port_record_index: int | None = None
    signal_code: int | None = None
    declared_port_index: int | None = None
    encoding: int | None = None
    name: str | None = None
    description: str | None = None
    connections: list[Connection] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["offset"] = f"0x{self.offset:x}"
        return result


def parse_macro_metadata(data: bytes, module: Module) -> None:
    """Parse the verified common header used by kind-4 macro modules."""
    try:
        name, after_name = decode_nrkt_string(data, module.offset + 0x104)
        description, after_description = decode_nrkt_string(data, after_name)
    except ValueError:
        return

    close = data.find(b"]", after_description, min(len(data), after_description + 32))
    if close < 0 or close + 9 > len(data):
        return

    # The dword immediately following ']' is consistently 4 for macros.  The
    # next dword is the number of immediate children serialized after it.
    if u32(data, close + 1) != 4:
        return

    module.name = name
    module.description = description or None
    module.child_count = u32(data, close + 5)
    module.input_count = u32(data, module.offset + 0x20)
    module.output_count = u32(data, module.offset + 0x24)
    module.x = signed_u32(u32(data, module.offset + 0x30))
    module.y = signed_u32(u32(data, module.offset + 0x34))
    module.width = u32(data, module.offset + 0x38)
    module.height = u32(data, module.offset + 0x3C)


def parse_modules(data: bytes) -> tuple[list[Module], list[Module]]:
    modules: list[Module] = []
    special_roots: list[Module] = []

    for offset in marker_offsets(data, MODULE_MARKER):
        if offset + 28 > len(data):
            continue
        version, signature, kind, object_id = struct.unpack_from("<IIII", data, offset + 12)
        if signature != MODULE_SIGNATURE:
            continue
        module = Module(offset, version, signature, kind, object_id)
        if kind == 4:
            parse_macro_metadata(data, module)
        if object_id == ROOT_SENTINEL_ID:
            special_roots.append(module)
        else:
            modules.append(module)

    # An Ensemble embeds an instrument as kind 9.  Its variable-sized header
    # uses the same `]`, dword 4, immediate-child-count trailer as a macro.
    # Parsing this boundary keeps the instrument's local connection indices in
    # a separate scope from the Ensemble's own modules.
    for index, module in enumerate(modules):
        if module.kind != 9:
            continue
        end = modules[index + 1].offset if index + 1 < len(modules) else len(data)
        cursor = module.offset
        while True:
            close = data.find(b"]", cursor, end)
            if close < 0:
                break
            if close + 9 <= end and u32(data, close + 1) == 4:
                candidate = u32(data, close + 5)
                if 0 < candidate < 10000:
                    module.child_count = candidate
            cursor = close + 1

    return modules, special_roots


def signed_u32(value: int) -> int:
    return value - (1 << 32) if value & (1 << 31) else value


def parse_output_port(data: bytes, offset: int) -> PortRecord:
    marker_size = 1 + 4 + len(b"KOutPort")
    cursor = offset + marker_size
    version, signal_code, declared_port_index, encoding = struct.unpack_from(
        "<IIII", data, cursor
    )
    cursor += 16
    if version != 1:
        raise ValueError(f"unsupported KOutPort version {version} at 0x{offset:x}")

    name: str | None = None
    description: str | None = None
    if encoding == 0:
        name, cursor = decode_nrkt_string(data, cursor)
        description, cursor = decode_nrkt_string(data, cursor)
    elif encoding == 2:
        description, cursor = decode_nrkt_string(data, cursor)
    elif encoding == 4:
        name, cursor = decode_nrkt_string(data, cursor)
    elif encoding not in (6, 22):
        raise ValueError(f"unknown KOutPort encoding {encoding} at 0x{offset:x}")

    connection_count = u32(data, cursor)
    cursor += 4
    if connection_count > 10000:
        raise ValueError(f"implausible connection count at 0x{offset:x}")
    connections: list[Connection] = []
    for _ in range(connection_count):
        target_local_index = u32(data, cursor)
        target_input_index = u32(data, cursor + 4)
        cursor += 8
        connections.append(Connection(target_local_index, target_input_index))

    if cursor >= len(data) or data[cursor] != ord("]"):
        raise ValueError(f"KOutPort did not end at predicted offset 0x{cursor:x}")

    return PortRecord(
        offset=offset,
        class_name="KOutPort",
        signal_code=signal_code,
        declared_port_index=signed_u32(declared_port_index),
        encoding=encoding,
        name=name,
        description=description,
        connections=connections,
    )


def parse_input_port(data: bytes, offset: int) -> PortRecord:
    marker_size = 1 + 4 + len(b"KInPort")
    cursor = offset + marker_size
    (
        version,
        signal_code,
        declared_port_index,
        _source_module,
        _source_port,
        encoding,
    ) = struct.unpack_from("<IIIIII", data, cursor)
    cursor += 24
    if version != 1:
        raise ValueError(f"unsupported KInPort version {version} at 0x{offset:x}")

    name: str | None = None
    description: str | None = None
    variant = encoding & 0x7
    if variant == 0:
        name, cursor = decode_nrkt_string(data, cursor)
        description, cursor = decode_nrkt_string(data, cursor)
    elif variant == 2:
        description, cursor = decode_nrkt_string(data, cursor)
    elif variant == 4:
        name, cursor = decode_nrkt_string(data, cursor)
    elif variant != 6:
        raise ValueError(f"unknown KInPort encoding {encoding} at 0x{offset:x}")

    if cursor >= len(data) or data[cursor] != ord("]"):
        raise ValueError(f"KInPort did not end at predicted offset 0x{cursor:x}")

    return PortRecord(
        offset=offset,
        class_name="KInPort",
        signal_code=signal_code,
        declared_port_index=signed_u32(declared_port_index),
        encoding=encoding,
        name=name,
        description=description,
    )


def parse_ports(data: bytes, modules: list[Module]) -> tuple[list[PortRecord], list[str]]:
    ports: list[PortRecord] = []
    warnings: list[str] = []
    module_offsets = [module.offset for module in modules]
    input_indices: Counter[int] = Counter()
    output_indices: Counter[int] = Counter()

    for class_bytes in PORT_CLASSES:
        marker = b"[" + struct.pack("<I", len(class_bytes)) + class_bytes
        for offset in marker_offsets(data, marker):
            if class_bytes == b"KOutPort":
                try:
                    port = parse_output_port(data, offset)
                except ValueError as error:
                    warnings.append(str(error))
                    port = PortRecord(offset, "KOutPort")
            else:
                try:
                    port = parse_input_port(data, offset)
                except ValueError as error:
                    warnings.append(str(error))
                    port = PortRecord(offset, "KInPort")

            source_index = bisect.bisect_right(module_offsets, offset) - 1
            if source_index >= 0:
                source_id = modules[source_index].object_id
                port.source_object_id = source_id
                if port.class_name == "KInPort":
                    port.source_port_record_index = input_indices[source_id]
                    input_indices[source_id] += 1
                else:
                    port.source_port_record_index = output_indices[source_id]
                    output_indices[source_id] += 1
            ports.append(port)
    return sorted(ports, key=lambda port: port.offset), warnings


def build_forest(modules: list[Module]) -> tuple[list[Module], list[str]]:
    """Use macro child counts to consume the pre-order module stream."""
    warnings: list[str] = []

    def consume(index: int) -> tuple[Module, int]:
        node = modules[index]
        next_index = index + 1
        node.children = []
        for child_number in range(node.child_count):
            if next_index >= len(modules):
                warnings.append(
                    f"{node.label()} id={node.object_id} expects {node.child_count} children; "
                    f"stream ended at child {child_number}"
                )
                break
            child, next_index = consume(next_index)
            node.children.append(child)
        return node, next_index

    forest: list[Module] = []
    index = 0
    while index < len(modules):
        node, index = consume(index)
        forest.append(node)
    return forest, warnings


def resolve_connections(forest: list[Module], ports: list[PortRecord]) -> list[dict[str, Any]]:
    modules_by_id: dict[int, Module] = {}
    sibling_scopes: dict[int, list[Module]] = {}

    def index_scope(scope: list[Module]) -> None:
        for node in scope:
            modules_by_id[node.object_id] = node
            sibling_scopes[node.object_id] = scope
            index_scope(node.children)

    index_scope(forest)
    input_ports = {
        (port.source_object_id, port.source_port_record_index): port
        for port in ports
        if port.class_name == "KInPort" and port.source_object_id is not None
    }
    wires: list[dict[str, Any]] = []
    for port in ports:
        if port.class_name != "KOutPort" or port.source_object_id is None:
            continue
        source = modules_by_id.get(port.source_object_id)
        scope = sibling_scopes.get(port.source_object_id, [])
        for connection in port.connections:
            if connection.target_local_index < len(scope):
                target = scope[connection.target_local_index]
                connection.target_object_id = target.object_id
                connection.target_name = target.name
                connection.target_kind = target.kind
                target_port = input_ports.get((target.object_id, connection.target_input_index))
                if target_port:
                    connection.target_input_name = target_port.name
            wires.append(
                {
                    "source_object_id": port.source_object_id,
                    "source_name": source.name if source else None,
                    "source_kind": source.kind if source else None,
                    "source_output_index": port.source_port_record_index,
                    "declared_port_index": port.declared_port_index,
                    **asdict(connection),
                }
            )
    return wires


def format_tree(nodes: list[Module], max_depth: int | None, macros_only: bool) -> str:
    lines: list[str] = []

    def visit(node: Module, depth: int) -> None:
        if not macros_only or node.is_macro:
            indent = "  " * depth
            suffix = f" children={node.child_count}" if node.is_macro else ""
            lines.append(
                f"{indent}{node.label()} [id={node.object_id}, kind={node.kind}, "
                f"offset=0x{node.offset:x}{suffix}]"
            )
            output_depth = depth + 1
        else:
            # Do not add a visual indentation level for hidden primitive nodes.
            output_depth = depth

        if max_depth is None or output_depth <= max_depth:
            for child in node.children:
                visit(child, output_depth)

    for root in nodes:
        visit(root, 0)
    return "\n".join(lines)


def format_dot(nodes: list[Module], wires: list[dict[str, Any]]) -> str:
    def escape(value: str) -> str:
        return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")

    flattened: list[Module] = []

    def collect(scope: list[Module]) -> None:
        for node in scope:
            flattened.append(node)
            collect(node.children)

    collect(nodes)
    lines = [
        "digraph ReaktorPatch {",
        "  graph [rankdir=LR, overlap=false, splines=true];",
        '  node [shape=box, fontname="Helvetica", fontsize=10];',
        '  edge [fontname="Helvetica", fontsize=8];',
    ]
    for node in flattened:
        title = node.name or f"kind {node.kind}"
        label = escape(f"{title}\\nid {node.object_id} · kind {node.kind}")
        lines.append(f'  n{node.object_id} [label="{label}"];')
    for wire in wires:
        target = wire.get("target_object_id")
        if target is None:
            continue
        output = f"out {wire.get('source_output_index', '?')}"
        input_label = wire.get("target_input_name") or f"in {wire['target_input_index']}"
        edge_label = escape(f"{output} → {input_label}")
        lines.append(
            f'  n{wire["source_object_id"]} -> n{target} [label="{edge_label}"];'
        )
    lines.append("}")
    return "\n".join(lines) + "\n"


def make_report(path: Path) -> dict[str, Any]:
    data = path.read_bytes()
    modules, special_roots = parse_modules(data)
    forest, warnings = build_forest(modules)
    ports, port_warnings = parse_ports(data, modules)
    wires = resolve_connections(forest, ports)
    kinds = Counter(module.kind for module in modules)

    return {
        "source": str(path.resolve()),
        "size_bytes": len(data),
        "nrkt_headers": [f"0x{offset:x}" for offset in marker_offsets(data, b"NRKT")],
        "counts": {
            "modules": len(modules),
            "special_root_records": len(special_roots),
            "input_ports": sum(port.class_name == "KInPort" for port in ports),
            "output_ports": sum(port.class_name == "KOutPort" for port in ports),
            "connections": len(wires),
            "resolved_connections": sum(wire["target_object_id"] is not None for wire in wires),
            "module_kinds": {str(kind): count for kind, count in sorted(kinds.items())},
        },
        "special_roots": [root.to_dict() for root in special_roots],
        "top_level": [node.to_dict() for node in forest],
        "ports": [port.to_dict() for port in ports],
        "connections": wires,
        "warnings": warnings + port_warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Extract the verified object hierarchy from a Reaktor NRKT binary."
    )
    parser.add_argument("file", type=Path, help="Reaktor .ism or .ens file")
    parser.add_argument("--json", action="store_true", help="emit the complete JSON report")
    parser.add_argument(
        "--wires", action="store_true", help="emit only the resolved connection table as JSON"
    )
    parser.add_argument("--dot", action="store_true", help="emit a Graphviz DOT graph")
    parser.add_argument(
        "--macros-only", action="store_true", help="hide primitive modules in tree output"
    )
    parser.add_argument(
        "--max-depth", type=int, default=None, help="limit printed tree depth"
    )
    args = parser.parse_args()

    report = make_report(args.file)
    if args.dot:
        data = args.file.read_bytes()
        modules, _ = parse_modules(data)
        forest, _ = build_forest(modules)
        print(format_dot(forest, report["connections"]), end="")
        return
    if args.wires:
        print(json.dumps(report["connections"], ensure_ascii=False, indent=2))
        return
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return

    print(f"Source: {report['source']}")
    print(f"Size: {report['size_bytes']} bytes")
    print(json.dumps(report["counts"], ensure_ascii=False, indent=2))
    print("\nHierarchy:")

    # Reparse rather than rebuilding dataclasses from the JSON representation.
    data = args.file.read_bytes()
    modules, _ = parse_modules(data)
    forest, warnings = build_forest(modules)
    print(format_tree(forest, args.max_depth, args.macros_only))
    if warnings:
        print("\nWarnings:")
        for warning in warnings:
            print(f"- {warning}")


if __name__ == "__main__":
    main()
