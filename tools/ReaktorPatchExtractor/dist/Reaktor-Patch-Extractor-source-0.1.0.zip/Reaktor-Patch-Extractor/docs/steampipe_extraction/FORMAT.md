# Notes sobre el format binari NRKT

Aquest document descriu només els camps comprovats empíricament amb
`SteamPipe.ism` i `SteamPipe_santi_2.ens`. Els enters són `uint32` little-endian,
excepte quan s'indica el contrari.

## Registres de classe

Els objectes serialitzats comencen així:

```text
0x5b                     '['
uint32                   longitud del nom de classe
bytes[length]            nom ASCII de classe
...                      payload de la classe
0x5d                     ']'
```

Classes verificades: `KSModul`, `KInPort` i `KOutPort`.

## KSModul

Capçalera comuna observada:

```text
+0x00  '[' + uint32(7) + "KSModul"
+0x0c  uint32 version        (1)
+0x10  uint32 signature      (0x0022f300)
+0x14  uint32 kind           tipus numèric de mòdul
+0x18  uint32 object_id      ID global dins del fitxer
```

L'arrel especial té `object_id = 0x75646f4d` (`Modu` en bytes) i segueix un
esquema diferent; no s'ha de confondre amb un mòdul ordinari.

### Macro (`kind = 4`)

Els camps següents són estables en les macros examinades:

```text
+0x20  uint32 input_count
+0x24  uint32 output_count
+0x30  int32  x
+0x34  int32  y
+0x38  uint32 width
+0x3c  uint32 height
+0x104 uint32 name_length + UTF-8 name
       uint32 description_length + UTF-8 description
       ']'
       uint32 4
       uint32 immediate_child_count
```

Els mòduls fills apareixen immediatament després en preordre. Per tant, el
`immediate_child_count` permet reconstruir tot l'arbre sense delimitadors
addicionals.

Un instrument incrustat dins un Ensemble (`kind = 9`) també acaba la seva
capçalera variable amb `']' + uint32(4) + uint32(child_count)`.

## KOutPort i connexions

Capçalera:

```text
uint32 version                 (1)
uint32 signal_code
int32  declared_port_index     (-1 en molts ports externs de macro)
uint32 encoding
```

Metadades segons `encoding`:

- `0`: nom i descripció, tots dos `uint32 length + UTF-8`;
- `2`: descripció;
- `4`: nom;
- `6` o `22`: cap text.

El final del registre és sempre:

```text
uint32 connection_count
repeat connection_count times:
    uint32 target_local_module_index
    uint32 target_input_index
0x5d
```

`target_local_module_index` indexa la llista de fills del mateix contenidor que
el mòdul origen. Resoldre aquesta referència contra l'arbre converteix totes les
connexions locals en `object_id` globals.

## KInPort

Capçalera verificada:

```text
uint32 version
uint32 signal_code
int32  declared_port_index
uint32 source_module_sentinel
uint32 source_port_sentinel
uint32 encoding
```

Els tres bits baixos d'`encoding` descriuen el text amb el mateix esquema
`0/2/4/6` de `KOutPort`. Això permet recuperar noms d'entrada com `L` i `R` i
assignar-los a les connexions resoltes.

## Resultats de regressió SteamPipe

| Fitxer | Mòduls ordinaris | Macros | Entrades | Sortides | Connexions | Resoltes |
|---|---:|---:|---:|---:|---:|---:|
| `SteamPipe.ism` | 947 | 90 | 1.011 | 896 | 989 | 989 |
| `SteamPipe_santi_2.ens` | 950 | 90 | 1.013 | 896 | 991 | 991 |

Les dues connexions addicionals de l'`.ens` pertanyen a l'embolcall de
l'Ensemble. Els IDs globals canvien, però la jerarquia de l'instrument i el seu
cablejat són equivalents.
