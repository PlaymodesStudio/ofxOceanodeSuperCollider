#!/usr/bin/env python3
"""Cross-check the Python and native Swift NRKT parsers on real files."""

from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
PYTHON_PARSER = REPO / "docs/steampipe_extraction/parse_nrkt.py"
NATIVE_PARSER = HERE / "dist/Reaktor Patch Extractor.app/Contents/MacOS/ReaktorPatchExtractor"


def load_python_parser():
    spec = importlib.util.spec_from_file_location("parse_nrkt", PYTHON_PARSER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {PYTHON_PARSER}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def native_report(path: Path) -> dict:
    completed = subprocess.run(
        [NATIVE_PARSER, path], check=True, stdout=subprocess.PIPE, text=True
    )
    return json.loads(completed.stdout)


def wire_signature(report: dict) -> set[tuple]:
    return {
        (
            wire["source_object_id"],
            wire.get("source_output_index"),
            wire.get("target_object_id"),
            wire["target_input_index"],
        )
        for wire in report["connections"]
    }


def verify(path: Path, parser) -> None:
    python_report = parser.make_report(path)
    swift_report = native_report(path)
    keys = (
        "modules",
        "special_root_records",
        "input_ports",
        "output_ports",
        "connections",
        "resolved_connections",
    )
    for key in keys:
        assert python_report["counts"][key] == swift_report["counts"][key], key
    assert python_report["warnings"] == [], python_report["warnings"]
    assert swift_report["warnings"] == [], swift_report["warnings"]
    assert wire_signature(python_report) == wire_signature(swift_report)
    assert python_report["counts"]["connections"] == python_report["counts"]["resolved_connections"]
    print(f"OK {path.name}: {python_report['counts']['modules']} modules, "
          f"{python_report['counts']['connections']} connections")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+", type=Path)
    args = parser.parse_args()
    if not NATIVE_PARSER.exists():
        raise SystemExit(f"Build the app first: {HERE / 'build.sh'}")
    implementation = load_python_parser()
    for path in args.files:
        verify(path, implementation)


if __name__ == "__main__":
    main()
