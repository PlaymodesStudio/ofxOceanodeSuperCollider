# Reaktor Patch Extractor

Aplicació macOS universal (`arm64` i `x86_64`) i executable de terminal per
inspeccionar fitxers binaris `NRKT` de Reaktor (`.ism` i `.ens`). És només de
lectura.

## Aplicació

Obre `dist/Reaktor Patch Extractor.app`, selecciona un fitxer i exporta:

- JSON: jerarquia, mòduls, macros, ports i connexions resoltes;
- DOT: graf complet compatible amb Graphviz.

## Terminal

El mateix binari funciona sense interfície gràfica:

```bash
"dist/Reaktor Patch Extractor.app/Contents/MacOS/ReaktorPatchExtractor" patch.ism > patch.json
"dist/Reaktor Patch Extractor.app/Contents/MacOS/ReaktorPatchExtractor" --summary patch.ism
"dist/Reaktor Patch Extractor.app/Contents/MacOS/ReaktorPatchExtractor" --dot patch.ism > patch.dot
```

## Compilació

Requereix les Command Line Tools de Xcode:

```bash
chmod +x build.sh
./build.sh
```

El parser Swift és autònom i no necessita Python. La implementació Python de
referència es manté a `docs/steampipe_extraction/parse_nrkt.py`.

## Verificació creuada

Després de compilar, compara la sortida Swift amb la implementació Python:

```bash
python3 verify_parsers.py patch.ism patch.ens
```

La gramàtica binària coneguda està documentada a
`docs/steampipe_extraction/FORMAT.md`.
