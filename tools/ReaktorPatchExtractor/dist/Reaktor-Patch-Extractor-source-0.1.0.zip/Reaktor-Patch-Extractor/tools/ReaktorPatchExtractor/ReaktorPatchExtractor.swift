import AppKit
import Foundation
import UniformTypeIdentifiers

private let moduleSignature: UInt32 = 0x0022F300
private let rootSentinelID: UInt32 = 0x75646F4D

enum NRKTError: LocalizedError {
    case truncated(Int)
    case invalid(String)

    var errorDescription: String? {
        switch self {
        case .truncated(let offset): return "Fitxer truncat prop de 0x\(String(offset, radix: 16))"
        case .invalid(let message): return message
        }
    }
}

final class ModuleNode {
    let offset: Int
    let version: UInt32
    let kind: UInt32
    let objectID: UInt32
    var name: String?
    var detail: String?
    var childCount = 0
    var inputCount: UInt32?
    var outputCount: UInt32?
    var x: Int32?
    var y: Int32?
    var width: UInt32?
    var height: UInt32?
    var children: [ModuleNode] = []

    init(offset: Int, version: UInt32, kind: UInt32, objectID: UInt32) {
        self.offset = offset
        self.version = version
        self.kind = kind
        self.objectID = objectID
    }

    var label: String { name?.isEmpty == false ? name! : "kind-\(kind)" }

    func jsonObject() -> [String: Any] {
        var result: [String: Any] = [
            "offset": String(format: "0x%x", offset),
            "version": version,
            "signature": "0x0022f300",
            "kind": kind,
            "object_id": objectID,
            "child_count": childCount,
            "children": children.map { $0.jsonObject() }
        ]
        if let name { result["name"] = name }
        if let detail, !detail.isEmpty { result["description"] = detail }
        if let inputCount { result["input_count"] = inputCount }
        if let outputCount { result["output_count"] = outputCount }
        if let x { result["x"] = x }
        if let y { result["y"] = y }
        if let width { result["width"] = width }
        if let height { result["height"] = height }
        return result
    }
}

struct ConnectionRecord {
    let targetLocalIndex: UInt32
    let targetInputIndex: UInt32
}

struct PortRecord {
    let offset: Int
    let className: String
    var sourceObjectID: UInt32?
    var sourcePortRecordIndex: Int?
    var signalCode: UInt32?
    var declaredPortIndex: Int32?
    var encoding: UInt32?
    var name: String?
    var detail: String?
    var connections: [ConnectionRecord] = []

    func jsonObject() -> [String: Any] {
        var result: [String: Any] = [
            "offset": String(format: "0x%x", offset),
            "class_name": className,
            "connections": connections.map {
                ["target_local_index": $0.targetLocalIndex,
                 "target_input_index": $0.targetInputIndex]
            }
        ]
        if let sourceObjectID { result["source_object_id"] = sourceObjectID }
        if let sourcePortRecordIndex { result["source_port_record_index"] = sourcePortRecordIndex }
        if let signalCode { result["signal_code"] = signalCode }
        if let declaredPortIndex { result["declared_port_index"] = declaredPortIndex }
        if let encoding { result["encoding"] = encoding }
        if let name { result["name"] = name }
        if let detail, !detail.isEmpty { result["description"] = detail }
        return result
    }
}

struct WireRecord {
    let sourceObjectID: UInt32
    let sourceName: String?
    let sourceKind: UInt32?
    let sourceOutputIndex: Int?
    let declaredPortIndex: Int32?
    let targetLocalIndex: UInt32
    let targetInputIndex: UInt32
    let targetObjectID: UInt32?
    let targetName: String?
    let targetKind: UInt32?
    let targetInputName: String?

    func jsonObject() -> [String: Any] {
        var result: [String: Any] = [
            "source_object_id": sourceObjectID,
            "target_local_index": targetLocalIndex,
            "target_input_index": targetInputIndex
        ]
        if let sourceName { result["source_name"] = sourceName }
        if let sourceKind { result["source_kind"] = sourceKind }
        if let sourceOutputIndex { result["source_output_index"] = sourceOutputIndex }
        if let declaredPortIndex { result["declared_port_index"] = declaredPortIndex }
        if let targetObjectID { result["target_object_id"] = targetObjectID }
        if let targetName { result["target_name"] = targetName }
        if let targetKind { result["target_kind"] = targetKind }
        if let targetInputName { result["target_input_name"] = targetInputName }
        return result
    }
}

struct ParseReport {
    let sourceURL: URL
    let size: Int
    let nrktHeaders: [Int]
    let modules: [ModuleNode]
    let specialRootCount: Int
    let forest: [ModuleNode]
    let ports: [PortRecord]
    let wires: [WireRecord]
    let warnings: [String]

    var inputPortCount: Int { ports.filter { $0.className == "KInPort" }.count }
    var outputPortCount: Int { ports.filter { $0.className == "KOutPort" }.count }
    var macroCount: Int { modules.filter { $0.kind == 4 }.count }
    var resolvedWireCount: Int { wires.filter { $0.targetObjectID != nil }.count }

    func jsonData() throws -> Data {
        var kinds: [String: Int] = [:]
        for module in modules { kinds[String(module.kind), default: 0] += 1 }
        let object: [String: Any] = [
            "source": sourceURL.path,
            "size_bytes": size,
            "nrkt_headers": nrktHeaders.map { String(format: "0x%x", $0) },
            "counts": [
                "modules": modules.count,
                "special_root_records": specialRootCount,
                "macros": macroCount,
                "input_ports": inputPortCount,
                "output_ports": outputPortCount,
                "connections": wires.count,
                "resolved_connections": resolvedWireCount,
                "module_kinds": kinds
            ],
            "top_level": forest.map { $0.jsonObject() },
            "ports": ports.map { $0.jsonObject() },
            "connections": wires.map { $0.jsonObject() },
            "warnings": warnings
        ]
        return try JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys])
    }

    func dotText() -> String {
        func escaped(_ value: String) -> String {
            value.replacingOccurrences(of: "\\", with: "\\\\")
                .replacingOccurrences(of: "\"", with: "\\\"")
                .replacingOccurrences(of: "\n", with: "\\n")
        }
        var lines = [
            "digraph ReaktorPatch {",
            "  graph [rankdir=LR, overlap=false, splines=true];",
            "  node [shape=box, fontname=\"Helvetica\", fontsize=10];",
            "  edge [fontname=\"Helvetica\", fontsize=8];"
        ]
        for module in modules {
            let title = module.name ?? "kind \(module.kind)"
            lines.append("  n\(module.objectID) [label=\"\(escaped(title))\\nid \(module.objectID) · kind \(module.kind)\"];")
        }
        for wire in wires {
            guard let target = wire.targetObjectID else { continue }
            let input = wire.targetInputName ?? "in \(wire.targetInputIndex)"
            let output = wire.sourceOutputIndex.map { "out \($0)" } ?? "out"
            lines.append("  n\(wire.sourceObjectID) -> n\(target) [label=\"\(escaped(output)) → \(escaped(input))\"];")
        }
        lines.append("}")
        return lines.joined(separator: "\n") + "\n"
    }

    func summaryText() -> String {
        var lines = [
            "Reaktor Patch Extractor",
            "",
            "Fitxer: \(sourceURL.path)",
            "Mida: \(size) bytes",
            "Mòduls: \(modules.count) (\(macroCount) macros)",
            "Ports: \(inputPortCount) entrades · \(outputPortCount) sortides",
            "Connexions: \(wires.count) · resoltes: \(resolvedWireCount)",
            "Avisos: \(warnings.count)",
            "",
            "Jerarquia de macros:",
        ]
        func visit(_ nodes: [ModuleNode], _ depth: Int) {
            for node in nodes {
                if node.kind == 4 || node.kind == 9 {
                    lines.append(String(repeating: "  ", count: depth) + "• \(node.label) [id \(node.objectID), kind \(node.kind), fills \(node.childCount)]")
                    visit(node.children, depth + 1)
                } else {
                    visit(node.children, depth)
                }
            }
        }
        visit(forest, 0)
        if !warnings.isEmpty {
            lines.append("")
            lines.append("Avisos:")
            lines.append(contentsOf: warnings.map { "• \($0)" })
        }
        return lines.joined(separator: "\n")
    }
}

final class NRKTParser {
    private let data: Data
    private let sourceURL: URL
    private let moduleMarker = Data([0x5b, 0x07, 0, 0, 0] + Array("KSModul".utf8))
    private let inPortMarker = Data([0x5b, 0x07, 0, 0, 0] + Array("KInPort".utf8))
    private let outPortMarker = Data([0x5b, 0x08, 0, 0, 0] + Array("KOutPort".utf8))

    init(url: URL) throws {
        sourceURL = url
        data = try Data(contentsOf: url, options: .mappedIfSafe)
    }

    private func u32(_ offset: Int) throws -> UInt32 {
        guard offset >= 0, offset + 4 <= data.count else { throw NRKTError.truncated(offset) }
        return UInt32(data[offset])
            | (UInt32(data[offset + 1]) << 8)
            | (UInt32(data[offset + 2]) << 16)
            | (UInt32(data[offset + 3]) << 24)
    }

    private func i32(_ value: UInt32) -> Int32 { Int32(bitPattern: value) }

    private func allOffsets(of marker: Data) -> [Int] {
        guard !marker.isEmpty, data.count >= marker.count else { return [] }
        var result: [Int] = []
        var cursor = 0
        while cursor <= data.count - marker.count,
              let range = data.range(of: marker, options: [], in: cursor..<data.count) {
            result.append(range.lowerBound)
            cursor = range.lowerBound + 1
        }
        return result
    }

    private func nrktString(_ lengthOffset: Int) throws -> (String, Int) {
        let length = Int(try u32(lengthOffset))
        guard length <= 1 << 20 else {
            throw NRKTError.invalid("Longitud de text inversemblant a 0x\(String(lengthOffset, radix: 16))")
        }
        let start = lengthOffset + 4
        let end = start + length
        guard end <= data.count else { throw NRKTError.truncated(start) }
        return (String(decoding: data[start..<end], as: UTF8.self), end)
    }

    private func parseMacroMetadata(_ module: ModuleNode) {
        do {
            let (name, afterName) = try nrktString(module.offset + 0x104)
            let (detail, afterDetail) = try nrktString(afterName)
            let limit = min(data.count, afterDetail + 32)
            guard afterDetail < limit,
                  let close = data[afterDetail..<limit].firstIndex(of: 0x5d),
                  close + 9 <= data.count,
                  try u32(close + 1) == 4 else { return }
            module.name = name
            module.detail = detail.isEmpty ? nil : detail
            module.childCount = Int(try u32(close + 5))
            module.inputCount = try u32(module.offset + 0x20)
            module.outputCount = try u32(module.offset + 0x24)
            module.x = i32(try u32(module.offset + 0x30))
            module.y = i32(try u32(module.offset + 0x34))
            module.width = try u32(module.offset + 0x38)
            module.height = try u32(module.offset + 0x3c)
        } catch { return }
    }

    private func parseModules() throws -> ([ModuleNode], Int) {
        var modules: [ModuleNode] = []
        var specialRoots = 0
        for offset in allOffsets(of: moduleMarker) {
            guard offset + 28 <= data.count else { continue }
            let version = try u32(offset + 12)
            guard try u32(offset + 16) == moduleSignature else { continue }
            let kind = try u32(offset + 20)
            let objectID = try u32(offset + 24)
            let module = ModuleNode(offset: offset, version: version, kind: kind, objectID: objectID)
            if kind == 4 { parseMacroMetadata(module) }
            if objectID == rootSentinelID { specialRoots += 1 } else { modules.append(module) }
        }

        for index in modules.indices where modules[index].kind == 9 {
            let module = modules[index]
            let end = index + 1 < modules.count ? modules[index + 1].offset : data.count
            var cursor = module.offset
            while cursor < end, let close = data[cursor..<end].firstIndex(of: 0x5d) {
                if close + 9 <= end, try u32(close + 1) == 4 {
                    let candidate = Int(try u32(close + 5))
                    if candidate > 0 && candidate < 10_000 { module.childCount = candidate }
                }
                cursor = close + 1
            }
        }
        return (modules, specialRoots)
    }

    private func buildForest(_ modules: [ModuleNode], warnings: inout [String]) -> [ModuleNode] {
        var index = 0
        func consume() -> ModuleNode? {
            guard index < modules.count else { return nil }
            let node = modules[index]
            index += 1
            node.children = []
            for childNumber in 0..<node.childCount {
                guard let child = consume() else {
                    warnings.append("\(node.label) esperava \(node.childCount) fills; el flux acaba al fill \(childNumber)")
                    break
                }
                node.children.append(child)
            }
            return node
        }
        var forest: [ModuleNode] = []
        while index < modules.count { if let node = consume() { forest.append(node) } }
        return forest
    }

    private func parseOutputPort(_ offset: Int) throws -> PortRecord {
        var cursor = offset + outPortMarker.count
        let version = try u32(cursor)
        let signal = try u32(cursor + 4)
        let declared = i32(try u32(cursor + 8))
        let encoding = try u32(cursor + 12)
        cursor += 16
        guard version == 1 else { throw NRKTError.invalid("Versió KOutPort \(version) no suportada") }
        var name: String?
        var detail: String?
        switch encoding {
        case 0:
            (name, cursor) = try nrktString(cursor)
            (detail, cursor) = try nrktString(cursor)
        case 2: (detail, cursor) = try nrktString(cursor)
        case 4: (name, cursor) = try nrktString(cursor)
        case 6, 22: break
        default: throw NRKTError.invalid("Encoding KOutPort \(encoding) desconegut a 0x\(String(offset, radix: 16))")
        }
        let count = Int(try u32(cursor))
        cursor += 4
        guard count < 10_000 else { throw NRKTError.invalid("Massa connexions a 0x\(String(offset, radix: 16))") }
        var connections: [ConnectionRecord] = []
        for _ in 0..<count {
            connections.append(ConnectionRecord(targetLocalIndex: try u32(cursor), targetInputIndex: try u32(cursor + 4)))
            cursor += 8
        }
        guard cursor < data.count, data[cursor] == 0x5d else {
            throw NRKTError.invalid("Final KOutPort inesperat a 0x\(String(cursor, radix: 16))")
        }
        return PortRecord(offset: offset, className: "KOutPort", signalCode: signal,
                          declaredPortIndex: declared, encoding: encoding,
                          name: name, detail: detail, connections: connections)
    }

    private func parseInputPort(_ offset: Int) throws -> PortRecord {
        var cursor = offset + inPortMarker.count
        let version = try u32(cursor)
        let signal = try u32(cursor + 4)
        let declared = i32(try u32(cursor + 8))
        let encoding = try u32(cursor + 20)
        cursor += 24
        guard version == 1 else { throw NRKTError.invalid("Versió KInPort \(version) no suportada") }
        var name: String?
        var detail: String?
        switch encoding & 0x7 {
        case 0:
            (name, cursor) = try nrktString(cursor)
            (detail, cursor) = try nrktString(cursor)
        case 2: (detail, cursor) = try nrktString(cursor)
        case 4: (name, cursor) = try nrktString(cursor)
        case 6: break
        default: throw NRKTError.invalid("Encoding KInPort \(encoding) desconegut a 0x\(String(offset, radix: 16))")
        }
        guard cursor < data.count, data[cursor] == 0x5d else {
            throw NRKTError.invalid("Final KInPort inesperat a 0x\(String(cursor, radix: 16))")
        }
        return PortRecord(offset: offset, className: "KInPort", signalCode: signal,
                          declaredPortIndex: declared, encoding: encoding,
                          name: name, detail: detail)
    }

    private func precedingModuleIndex(_ offset: Int, in modules: [ModuleNode]) -> Int? {
        var low = 0
        var high = modules.count
        while low < high {
            let middle = (low + high) / 2
            if modules[middle].offset <= offset { low = middle + 1 } else { high = middle }
        }
        return low > 0 ? low - 1 : nil
    }

    private func parsePorts(_ modules: [ModuleNode], warnings: inout [String]) -> [PortRecord] {
        var markers = allOffsets(of: inPortMarker).map { ($0, "KInPort") }
        markers += allOffsets(of: outPortMarker).map { ($0, "KOutPort") }
        markers.sort { $0.0 < $1.0 }
        var inputIndices: [UInt32: Int] = [:]
        var outputIndices: [UInt32: Int] = [:]
        var ports: [PortRecord] = []
        for (offset, className) in markers {
            do {
                var port = try className == "KInPort" ? parseInputPort(offset) : parseOutputPort(offset)
                if let moduleIndex = precedingModuleIndex(offset, in: modules) {
                    let sourceID = modules[moduleIndex].objectID
                    port.sourceObjectID = sourceID
                    if className == "KInPort" {
                        port.sourcePortRecordIndex = inputIndices[sourceID, default: 0]
                        inputIndices[sourceID, default: 0] += 1
                    } else {
                        port.sourcePortRecordIndex = outputIndices[sourceID, default: 0]
                        outputIndices[sourceID, default: 0] += 1
                    }
                }
                ports.append(port)
            } catch {
                warnings.append(error.localizedDescription + " (0x\(String(offset, radix: 16)))")
                ports.append(PortRecord(offset: offset, className: className))
            }
        }
        return ports
    }

    private func resolveWires(forest: [ModuleNode], ports: [PortRecord]) -> [WireRecord] {
        var modulesByID: [UInt32: ModuleNode] = [:]
        var scopesByID: [UInt32: [ModuleNode]] = [:]
        func index(_ scope: [ModuleNode]) {
            for node in scope {
                modulesByID[node.objectID] = node
                scopesByID[node.objectID] = scope
                index(node.children)
            }
        }
        index(forest)
        var inputNames: [String: String] = [:]
        for port in ports where port.className == "KInPort" {
            if let id = port.sourceObjectID, let position = port.sourcePortRecordIndex, let name = port.name {
                inputNames["\(id):\(position)"] = name
            }
        }
        var wires: [WireRecord] = []
        for port in ports where port.className == "KOutPort" {
            guard let sourceID = port.sourceObjectID else { continue }
            let source = modulesByID[sourceID]
            let scope = scopesByID[sourceID] ?? []
            for connection in port.connections {
                let localIndex = Int(connection.targetLocalIndex)
                let target = localIndex < scope.count ? scope[localIndex] : nil
                let inputName = target.flatMap { inputNames["\($0.objectID):\(connection.targetInputIndex)"] }
                wires.append(WireRecord(
                    sourceObjectID: sourceID, sourceName: source?.name, sourceKind: source?.kind,
                    sourceOutputIndex: port.sourcePortRecordIndex, declaredPortIndex: port.declaredPortIndex,
                    targetLocalIndex: connection.targetLocalIndex, targetInputIndex: connection.targetInputIndex,
                    targetObjectID: target?.objectID, targetName: target?.name, targetKind: target?.kind,
                    targetInputName: inputName))
            }
        }
        return wires
    }

    func parse() throws -> ParseReport {
        let (modules, specialRoots) = try parseModules()
        var warnings: [String] = []
        let forest = buildForest(modules, warnings: &warnings)
        let ports = parsePorts(modules, warnings: &warnings)
        let wires = resolveWires(forest: forest, ports: ports)
        let nrkt = allOffsets(of: Data("NRKT".utf8))
        return ParseReport(sourceURL: sourceURL, size: data.count, nrktHeaders: nrkt,
                           modules: modules, specialRootCount: specialRoots, forest: forest,
                           ports: ports, wires: wires, warnings: warnings)
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var window: NSWindow!
    private var textView: NSTextView!
    private var exportJSONButton: NSButton!
    private var exportDOTButton: NSButton!
    private var report: ParseReport?
    private var pendingURL: URL?

    func applicationDidFinishLaunching(_ notification: Notification) {
        buildWindow()
        if let pendingURL { load(pendingURL) }
    }

    private func buildWindow() {
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 900, height: 650),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "Reaktor Patch Extractor"
        window.center()

        let openButton = NSButton(title: "Obrir .ism / .ens…", target: self, action: #selector(openFile))
        exportJSONButton = NSButton(title: "Exportar JSON…", target: self, action: #selector(exportJSON))
        exportDOTButton = NSButton(title: "Exportar DOT…", target: self, action: #selector(exportDOT))
        exportJSONButton.isEnabled = false
        exportDOTButton.isEnabled = false

        let buttons = NSStackView(views: [openButton, exportJSONButton, exportDOTButton])
        buttons.orientation = .horizontal
        buttons.spacing = 10

        textView = NSTextView(frame: NSRect(x: 0, y: 0, width: 860, height: 560))
        textView.isEditable = false
        textView.isRichText = false
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.textContainer?.widthTracksTextView = true
        textView.textContainerInset = NSSize(width: 8, height: 8)
        textView.font = NSFont.monospacedSystemFont(ofSize: 12, weight: .regular)
        textView.string = "Obre un instrument .ism o un Ensemble .ens de Reaktor.\n\nL’aplicació és només de lectura."
        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.autohidesScrollers = true
        scroll.documentView = textView

        let root = NSView()
        window.contentView = root
        buttons.translatesAutoresizingMaskIntoConstraints = false
        scroll.translatesAutoresizingMaskIntoConstraints = false
        root.addSubview(buttons)
        root.addSubview(scroll)
        NSLayoutConstraint.activate([
            buttons.leadingAnchor.constraint(equalTo: root.leadingAnchor, constant: 16),
            buttons.topAnchor.constraint(equalTo: root.topAnchor, constant: 16),
            scroll.leadingAnchor.constraint(equalTo: root.leadingAnchor, constant: 16),
            scroll.trailingAnchor.constraint(equalTo: root.trailingAnchor, constant: -16),
            scroll.topAnchor.constraint(equalTo: buttons.bottomAnchor, constant: 12),
            scroll.bottomAnchor.constraint(equalTo: root.bottomAnchor, constant: -16)
        ])
        window.makeKeyAndOrderFront(nil)
    }

    @objc private func openFile() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = ["ism", "ens"].compactMap { UTType(filenameExtension: $0) }
        if panel.runModal() == .OK, let url = panel.url { load(url) }
    }

    private func load(_ url: URL) {
        do {
            let parsed = try NRKTParser(url: url).parse()
            report = parsed
            textView.string = parsed.summaryText()
            exportJSONButton.isEnabled = true
            exportDOTButton.isEnabled = true
            window.title = "Reaktor Patch Extractor — \(url.lastPathComponent)"
        } catch {
            report = nil
            textView.string = "No s’ha pogut analitzar el fitxer:\n\n\(error.localizedDescription)"
            exportJSONButton.isEnabled = false
            exportDOTButton.isEnabled = false
        }
    }

    private func savePanel(extension ext: String, source: URL) -> URL? {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [UTType(filenameExtension: ext)].compactMap { $0 }
        panel.nameFieldStringValue = source.deletingPathExtension().lastPathComponent + "-reaktor." + ext
        return panel.runModal() == .OK ? panel.url : nil
    }

    @objc private func exportJSON() {
        guard let report, let url = savePanel(extension: "json", source: report.sourceURL) else { return }
        do { try report.jsonData().write(to: url, options: .atomic) }
        catch { textView.string += "\n\nError exportant JSON: \(error.localizedDescription)" }
    }

    @objc private func exportDOT() {
        guard let report, let url = savePanel(extension: "dot", source: report.sourceURL) else { return }
        do { try report.dotText().write(to: url, atomically: true, encoding: .utf8) }
        catch { textView.string += "\n\nError exportant DOT: \(error.localizedDescription)" }
    }

    func application(_ sender: NSApplication, openFiles filenames: [String]) {
        guard let first = filenames.first else { return }
        let url = URL(fileURLWithPath: first)
        if window == nil { pendingURL = url } else { load(url) }
        sender.reply(toOpenOrPrint: .success)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

private func writeStdout(_ data: Data) {
    FileHandle.standardOutput.write(data)
    FileHandle.standardOutput.write(Data("\n".utf8))
}

let arguments = Array(CommandLine.arguments.dropFirst())
let fileArgument = arguments.first { !$0.hasPrefix("-") }
if let fileArgument {
    do {
        let report = try NRKTParser(url: URL(fileURLWithPath: fileArgument)).parse()
        if arguments.contains("--dot") {
            writeStdout(Data(report.dotText().utf8))
        } else if arguments.contains("--summary") {
            writeStdout(Data(report.summaryText().utf8))
        } else {
            writeStdout(try report.jsonData())
        }
        exit(0)
    } catch {
        FileHandle.standardError.write(Data(("Error: \(error.localizedDescription)\n").utf8))
        exit(1)
    }
} else {
    let app = NSApplication.shared
    let delegate = AppDelegate()
    app.delegate = delegate
    app.setActivationPolicy(.regular)
    app.activate(ignoringOtherApps: true)
    app.run()
}
